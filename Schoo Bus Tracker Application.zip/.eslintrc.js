module.exports = {
  root: true,
  extends: '@react-native',
};
